def soma(a, b):
  """Esta função retorna a soma de dois números."""
  return a + b